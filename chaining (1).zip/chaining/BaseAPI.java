package chaining;

public class BaseAPI {

	public static String sysID = ""; 
	
}
